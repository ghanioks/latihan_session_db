<?php

session_start();
	
	if(isset($_SESSION['message'])){
		if($_SESSION['message']!=""){
			echo "<span 
			style= 'color: red'>".$_SESSION['message']."</span>";
			$_SESSION['message'] = "";
		}
	}

?>
<!DOCTYPE html>
<html>
<head>
	<title>Login</title>
	<link rel="stylesheet" type="text/css" href="css.css">
</head>
<body>
	<form class="box" method="POST" action="ceklogin.php">
		<h2 class="h2">Sign In</h2>
		<table>
			<tr>
				<td><input placeholder="Username" type="text" name="username" required></td>
			</tr>
			<tr>
				<td><input placeholder="Password" type="password" name="password" required></td>
			</tr>
			<tr>
				<td><button class="button" type="submit" name="login">Sign In</button></td>
			</tr>
		</table>
		<h5 class="qq">Don't have an account?</h5>
		<a class="regist" href="register.php">Register in here</a>
	</form>
</body>
</html>