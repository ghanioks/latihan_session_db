<?php 

//register php

session_start();

if(isset($_SESSION['message'])){
	if($_SESSION['message']!=""){
		echo"<span
		style='color:red'>".$_SESSION['message']."</span>";
		$_SESSION['message']="";
	}
}


 ?>

<!DOCTYPE html>
<html>
<head>
	<title>Login</title>
	<link rel="stylesheet" type="text/css" href="register.css">
</head>
<body>
	<form class="box" method="POST" action="cekregister.php">
		<h2 class="h2">Register</h2>
		<table>
			<tr>
				<td><input placeholder="Username" type="text" name="username" required></td>
			</tr>
			<tr>
				<td><input placeholder="Password" type="password" name="password" required></td>
			</tr>
			<tr>
				<td><button class="button" type="submit" name="register">Register</button></td>
			</tr>
		</table>
		<h5 class="qq">Already have an account?</h5>
		<a class="regist" href="login.php">Login in here</a>
	</form>
</body>
</html>
